function p = multiquantreg(x,y,tau,order,Nboot)
% multi varibles Quantile Regression
% 
% USAGE: [p,stats]=quantreg(x,y,tau[,order,nboot]);
% 
% INPUTS: 
%   x,y: data that is fitted. (x and y should be columns)
%        Note: that if x is a matrix with several columns then multiple
%        linear regression is used and the "order" argument is not used.
%   tau: quantile used in regression. 
%   order: polynomial order. (default=1)
%          (negative orders are interpreted as zero intercept)
%   nboot: number of bootstrap surrogates used in statistical inference.(default=200)
%
% stats is a structure with the following fields:
%      .pse:    standard error on p. (not independent)
%      .pboot:  the bootstrapped polynomial coefficients.
%      .yfitci: 95% confidence interval on "polyval(p,x)" or "x*p"
%
% [If no output arguments are specified then the code will attempt to make a default test figure
% for convenience, which may not be appropriate for your data (especially if x is not sorted).]
%
% Note: uses bootstrap on residuals for statistical inference. (see help bootstrp)
% check also: http://www.econ.uiuc.edu/~roger/research/intro/rq.pdf
%
% EXAMPLE:
% x=(1:1000)';
% y=randn(size(x)).*(1+x/300)+(x/300).^2;
% [p,stats]=quantreg(x,y,.9,2);
% plot(x,y,x,polyval(p,x),x,stats.yfitci,'k:')
% legend('data','2nd order 90th percentile fit','95% confidence interval','location','best')
% 
% For references on the method check e.g. and refs therein:
% http://www.econ.uiuc.edu/~roger/research/rq/QRJEP.pdf
%
%  Copyright (C) 2008, Aslak Grinsted

%   This software may be used, copied, or redistributed as long as it is not
%   sold and this copyright notice is reproduced on each copy made.  This
%   routine is provided as is without any express or implied warranties
%   whatsoever.

if nargin<3
    error('Not enough input arguments.');
end
if nargin<4, order=[]; end
if nargin<5, Nboot=200; end

if (tau<=0)||(tau>=1)
    error('the percentile (tau) must be between 0 and 1.')
end

if size(x,1)~=size(y,1)
    error('length of x and y must be the same.');
end

if numel(y)~=size(y,1)
    error('y must be a column vector.')
end

X = ones(size(x,1),1);
switch order
    case 1
        box = 1:size(x,2);%1Ԫ==2Ŀ�� [1] ��Ԫ==��Ŀ��[1,2] 14Ԫ==15Ŀ��[1,2,3,4,5,6,7,8,9,10,11,12,13,14]
        C = nchoosek(box,1);%����һ���������а����˴����� v ��Ԫ����һ��ȡ k ��Ԫ�ص�������� C = size(x,2)��1
        for c = size(x,2):-1:1
            X = [x(:,C(c)),X];%ǰ��Ĵ����ߣ�����Ĵ�����
        end
        
        pmean=X\y;
        rho = @(r)sum(abs(r.*(tau-(r<0))));
        pp = @(p)rho(y-X*p);
        p = fminsearch(pp,pmean);
    case 2
        box = 1:size(x,2);
        C =cell(1,order);
        C{1} = nchoosek(box,1);
        for c = size(x,2):-1:1
            X = [x(:,C{1}(c)),X];%ǰ��Ĵ����ߣ�����Ĵ�����
        end
        if size(box,2) >=2
            C{2} = nchoosek(box,2);%C{2} = ?��2
            C{2} = flipud(C{2});
        end
        for i = size(x,2):-1:1
            C{2} = [C{2};i,i];
        end
        for c = 1:size(C{2},1)
            a = C{2}(c,1);
            b = C{2}(c,2);
            X = [x(:,a).*x(:,b),X];%ǰ��Ĵ����ߣ�����Ĵ�����
        end
        
        pmean=X\y;
        rho = @(r)sum(abs(r.*(tau-(r<0))));
        pp = @(p)rho(y-X*p);
        p = fminsearch(pp,pmean);
    otherwise
        disp('other value')
end

if nargout==0
    [xx,six]=sortrows(x(:,order));
    plot(xx,y(six),'.',x(six,order),x(six,:)*p,'r.-')
    legend('data',sprintf('quantreg-fit ptile=%.0f%%',tau*100),'location','best')
    clear p
    return
end 
    
end

% 
% 
% 
% function ps=invtranspoly(p,kx)
%
% ps=p;
% order=length(p);
% fact=cumprod(1:order);
% kx=cumprod(repmat(kx,1,order));
% for ii=2:order
%     for jj=1:ii-1
%         N=order-jj+1;
%         k=ii-jj;
%         k=min(k,N-k);
%         ps(ii)=ps(ii)+p(jj)*kk(k)*fact(N)/(fact(k)*fact(N-k));
%     end
% end




