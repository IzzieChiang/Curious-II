L = zeros(200,8);
for l = 1:size(L,1)
    L(l,:)=randperm(100,8)./100;
end
c = 7;
bu = ones(1,c);
bd = zeros(1,c);
% RBF����
nc = 10;
[ W2,B2,Centers,Spreads ] = RBF(L(:,1:c),L(:,c+1:end),nc);
% 
[time,P,gbest ] = DDEA_SE(c,L,bu,bd);
