function Archive = MONASelection(Population,Offspring,archive)
% The environmental selection of SAN-DE subpopulation
%
% Population  -original subpopulation 
% Offspring  --offspring after SDE
% 
%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    %% Parameter setting
    novelty_threshold = 0;
    % archive = Population;
    pop_size = size(Population,2);
    k = 10;
    % Calculate objective values
    PopObj    = Population.objs;
    OffObj    = Offspring.objs;
    [N,D]  = size(OffObj);
    
    %% Select by Novelty
    % The offsprings which can replace its parent 
    for i = 1:N
        if novelty_threshold < 0.0001
            novelty_threshold = individualKNN(PopObj,OffObj(i,:), D, k,pop_size);
            % add individual
            Archive = [archive,Offspring(i)];
        else
            individual_novelty= individualKNN(PopObj,OffObj(i,:), D, k,pop_size);
            if novelty_threshold < individual_novelty
                % add individual
                Archive = [archive,Offspring(i)];
            end
        end
    end
end

function novelty_threshold= individualKNN(PopObj,OffObj, D, k,pop_size)
	% calculating all distances
   
    for j=1:pop_size
		nearest_neighbors_distance(j)= 0;
		sum1=0;
        for m=1:D
			sum1 = sum1  + (OffObj(:,m)-PopObj(j,m))^2;
            %(individual[problem_size + m]- population[j][problem_size + m])*(individual[problem_size + m]- population[j][problem_size + m]);
        end
		nearest_neighbors_distance(j)= sqrt(sum1);        
    end
	
	%sorting nearest neighbors
	Rankneighbor = sort(nearest_neighbors_distance);

	%calculating the average distance between the k nearest 
	sum2 =  sum(Rankneighbor(1:k));
	novelty_threshold = sum2/k;
end