function SAN(Global)
% <algorithm> <G>
% Subpopulation Algorithm based on Novelty

%------------------------------- Reference --------------------------------
%  Vargas D V, Murata J, Takano H, et al. General subpopulation framework 
%  and taming the conflict inside populations[J]. Evolutionary computation, 
%  2015, 23(1): 1-36.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    %% Generate random population��initialization��
    subnum = 3; %_Subnum_parameter �ĳ�������
    Smatric =[0.3,0.3,0.4]*Global.N;
    SubPopulation01 = Global.Initialization(Smatric(1));%(obj,N)
    SubPopulation02 = Global.Initialization(Smatric(2));%(obj,N)
    SubPopulation03 = Global.Initialization(Smatric(3));
    Population ={SubPopulation01;SubPopulation02;SubPopulation03};
    Archive = [];%Population{1}; %����Ľ⼯������Ϊ��
    novelty_threshold = 0; %
    generation = SubPopulation01; %���Ըĳ������ѭ��������������
    n_rejectcounter = 0;
    generation_counter = 0;
    %% Optimization separately
    %Offspring = zeros(Global.N,Global.D);
    while Global.NotTermination(Archive) %ѭ��������ʱ��plot��evaluation = generation*10 �ܸ�����
        for i=1:subnum-1
            [Population{i}, Archive, novelty_threshold,generation_counter,n_rejectcounter] = SDEE(Population,i,Global.D,Archive,novelty_threshold,generation_counter,n_rejectcounter); %�����ǸĹ���population{i}
        end
        [Population{subnum}, Archive, novelty_threshold,generation_counter,n_rejectcounter] = SMONE(Population,Global.D,Archive,novelty_threshold,generation_counter,n_rejectcounter); %�����ǸĹ���population{i}
        generation = [SubPopulation01,Population{subnum}];
        
        
        if size(Archive,2) == 100
            STOP =2;
        end
        
        %sampling ����������Ҫ��        
        Anum = size(Archive,2);
        for m = 1:subnum %����һ������Ⱥ
            temprand = randperm(Anum,Smatric(m)); %�������Ⱥ�ĸ�����
            archive = Archive(temprand); %��ȡ����
            Population{m} = archive;
        end
        
    end
end

        %{
        % ɾ��dominated�ĸ���
        if size(Archive,2) >= 50
            NonDominated = NDSort(Archive.objs,1) == 1;
            archive   = Archive(NonDominated);
            while size(archive,2) < 10
                archive = [archive,Archive(end)];
                Archive = Archive(1:end-1);
            end
            Archive = archive;
        end
        %}

        