function Population = SDESelection(Population,Offspring,Plob)
% The environmental selection of SAN-DE subpopulation
% Population --original subpopulation 
% Offspring  --offspring after SDE
% Plob       --single objective(problem)
%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    %% Calculate objective values
    PopObj    = Population.objs;
    OffObj    = Offspring.objs;
    [N,D]  = size(PopObj);
    %% Select by non-dominated sorting
    % The offsprings which can replace its parent
    % Site = rand(N,D) <= 1;
    for i =1:N
        Site =  OffObj(i,Plob) < PopObj(i,Plob);
        if Site == true
            SelObj(i) = true;
        else
            SelObj(i) = false;
        end
    end
    Population(SelObj) = Offspring(SelObj);
    % �������⣺����֧��Ľ���ô�죬��Ŀ��û�л���֧��Ľ��
end    